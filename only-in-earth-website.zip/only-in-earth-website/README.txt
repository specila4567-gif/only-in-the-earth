ONLY IN EARTH website
=====================

1. Extract this ZIP file to a folder on your computer.
2. Open the folder in VS Code.
3. Open index.html and double-click it, or right-click and choose "Open with Live Server" if you have that extension.
4. Your real shop photo is in images/shop-front.jpg.

Before publishing online:
- Replace "Add your shop address", "Add your phone number", and "Add opening hours" in index.html with correct details.
- Update product prices with your actual prices.
- This is a starter site. The shopping list is for browsing only; it does not accept payments or send orders.
